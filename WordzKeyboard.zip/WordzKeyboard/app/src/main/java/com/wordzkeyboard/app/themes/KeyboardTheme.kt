package com.wordzkeyboard.app.themes

import com.wordzkeyboard.app.animation.AnimationType

data class KeyboardTheme(
    val id: String,
    val name: String,
    val bgTop: Int,
    val bgBottom: Int,
    val key: Int,
    val keyPressed: Int,
    val special: Int,
    val text: Int,
    val hint: Int,
    val accent: Int,
    val accent2: Int,
    val border: Int = 0,
    val glowBorder: Boolean = false,
    val rgb: Boolean = false,
    val raised: Boolean = false,
    val grid: Boolean = false,
    val radiusDp: Float = 8f,
    val defaultAnim: AnimationType = AnimationType.MINIMAL
)

private fun c(v: Long): Int = v.toInt()

object ThemeRegistry {
    val all: List<KeyboardTheme> = listOf(
        KeyboardTheme(
            "neon", "Neon Cyberpunk",
            c(0xFF120A2A), c(0xFF05050F), c(0xFF15152E), c(0xFF26264F), c(0xFF1C1B3C),
            c(0xFFE8F7FF), c(0xFF7A86B8), c(0xFF00F0FF), c(0xFFB14CFF),
            border = c(0xFF00F0FF), glowBorder = true, radiusDp = 9f,
            defaultAnim = AnimationType.NEON_FLASH
        ),
        KeyboardTheme(
            "rgb", "RGB Gaming",
            c(0xFF0B0B12), c(0xFF050508), c(0xFF171722), c(0xFF2A2A3C), c(0xFF1E1E2C),
            c(0xFFFFFFFF), c(0xFF8D8DA8), c(0xFFFF2D95), c(0xFF00E5FF),
            border = c(0xFFFFFFFF), glowBorder = true, rgb = true, radiusDp = 7f,
            defaultAnim = AnimationType.COLOR_SPLASH
        ),
        KeyboardTheme(
            "glass", "Glassmorphism",
            c(0xFF3F5EFB), c(0xFF8E44AD), c(0x33FFFFFF), c(0x66FFFFFF), c(0x22FFFFFF),
            c(0xFFFFFFFF), c(0xCCFFFFFF), c(0xFFFFFFFF), c(0xFFBBD0FF),
            border = c(0x80FFFFFF), radiusDp = 12f,
            defaultAnim = AnimationType.SOFT_BLOOM
        ),
        KeyboardTheme(
            "minimal", "Premium Minimal",
            c(0xFFF4F5F7), c(0xFFF4F5F7), c(0xFFFFFFFF), c(0xFFE2E4E9), c(0xFFE9EBEF),
            c(0xFF1C1C21), c(0xFF8A8F9A), c(0xFF2F6BFF), c(0xFF8A5CFF),
            radiusDp = 10f, defaultAnim = AnimationType.SPRING_POP
        ),
        KeyboardTheme(
            "raised", "3D Raised Keys",
            c(0xFF30333B), c(0xFF1F2127), c(0xFF4B5160), c(0xFF3D4250), c(0xFF383D49),
            c(0xFFF2F4F8), c(0xFFA0A6B5), c(0xFFFF9F1C), c(0xFFFFD166),
            raised = true, radiusDp = 7f, defaultAnim = AnimationType.PRESS_3D
        ),
        KeyboardTheme(
            "aurora", "Aurora",
            c(0xFF0A1F44), c(0xFF0F6B5E), c(0x33FFFFFF), c(0x55FFFFFF), c(0x22FFFFFF),
            c(0xFFFFFFFF), c(0xCCCFEFE8), c(0xFF7CFFCB), c(0xFF9B8CFF),
            border = c(0x55B8FFE8), radiusDp = 12f, defaultAnim = AnimationType.FLOATING
        ),
        KeyboardTheme(
            "matrix", "Matrix Grid",
            c(0xFF000000), c(0xFF03140A), c(0xFF06180C), c(0xFF0D3A1A), c(0xFF0A2412),
            c(0xFF2BFF6A), c(0xFF1E9E48), c(0xFF00FF41), c(0xFF00B33C),
            border = c(0x8000FF41), grid = true, radiusDp = 4f,
            defaultAnim = AnimationType.PARTICLE_BURST
        ),
        KeyboardTheme(
            "classic", "Classic Clean",
            c(0xFFD3D6DB), c(0xFFD3D6DB), c(0xFFFFFFFF), c(0xFFC9CDD3), c(0xFFB7BCC5),
            c(0xFF111111), c(0xFF6B7280), c(0xFF1A73E8), c(0xFF1A73E8),
            radiusDp = 6f, defaultAnim = AnimationType.MINIMAL
        )
    )

    val default: KeyboardTheme get() = all[0]
    fun byId(id: String): KeyboardTheme = all.firstOrNull { it.id == id } ?: default
    fun next(id: String): KeyboardTheme {
        val i = all.indexOfFirst { it.id == id }
        return all[(i + 1).mod(all.size)]
    }
}
