package com.wordzkeyboard.app.keyboard

import android.content.Context
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.AudioManager
import android.os.SystemClock
import android.util.SparseArray
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import androidx.core.graphics.ColorUtils
import com.wordzkeyboard.app.K
import com.wordzkeyboard.app.WordzSettings
import com.wordzkeyboard.app.animation.AnimationType
import com.wordzkeyboard.app.animation.KeyAnimationEngine
import com.wordzkeyboard.app.themes.KeyboardTheme
import com.wordzkeyboard.app.themes.ThemeRegistry
import kotlin.math.abs

/**
 * Single custom-drawn keyboard surface used both by the real IME and by the in-app
 * Animation Studio preview, so previews behave exactly like the keyboard.
 * Text is committed on key-up (key-down for backspace) and never waits for animations.
 */
class KeyboardView(context: Context) : View(context) {

    interface Listener {
        fun onKey(key: Key, alt: Boolean)
        fun onBackspace()
        fun onCursor(dir: Int)
        fun onSpaceLong()
    }

    var listener: Listener? = null

    private class Press(var index: Int, var lastX: Float) {
        var fired = false
        var moved = false
        var accum = 0f
        var longRun: Runnable? = null
        var repeatRun: Runnable? = null
    }

    private val dp = resources.displayMetrics.density
    private val engine = KeyAnimationEngine()
    private val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private var theme: KeyboardTheme = ThemeRegistry.default
    private var keys: List<Key> = emptyList()
    private var rowOf = IntArray(0)
    private var labels: Array<String> = emptyArray()
    private val rects = ArrayList<RectF>()
    private var rowCount = 4
    private var shift = 0
    private val presses = SparseArray<Press>()

    private var heightScale = 1f
    private var gapDp = 4f
    private var radiusScale = 1f
    private var labelScale = 1f
    private var haptic = true
    private var sound = false
    private var glow = true
    private var reduced = false

    private val bg = Paint()
    private val face = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val fx = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val hintP = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.RIGHT }
    private val gridP = Paint().apply { strokeWidth = 1f }
    private val tmp = RectF()
    private val path = Path()
    private val xf = FloatArray(2)
    private val hsv = FloatArray(3)
    private var shader: Shader? = null

    init { contentDescription = "WORDZ keyboard" }

    // ---------- configuration ----------

    fun applySettings(s: WordzSettings) {
        theme = ThemeRegistry.byId(s.str(K.THEME, "neon"))
        val a = s.str(K.ANIM, "auto")
        engine.type = if (a == "auto") theme.defaultAnim
        else runCatching { AnimationType.valueOf(a) }.getOrDefault(theme.defaultAnim)
        engine.speed = s.float(K.SPEED, 1f)
        engine.intensity = s.float(K.INTENSITY, 0.8f).coerceIn(0.2f, 1.2f)
        engine.particles = s.bool(K.PARTICLES, true)
        glow = s.bool(K.GLOW, true)
        engine.glow = glow
        val systemOff = try {
            android.provider.Settings.Global.getFloat(context.contentResolver, "animator_duration_scale", 1f) == 0f
        } catch (e: Exception) { false }
        reduced = s.bool(K.REDUCED, false) || systemOff
        engine.reduced = reduced
        haptic = s.bool(K.HAPTIC, true)
        sound = s.bool(K.SOUND, false)
        heightScale = s.float(K.HEIGHT, 1f)
        gapDp = s.float(K.GAP, 4f)
        radiusScale = s.float(K.RADIUS, 1f)
        labelScale = s.float(K.LABEL, 1f)
        updateShader()
        requestLayout()
        invalidate()
    }

    fun setLayout(rows: List<List<Key>>) {
        val flat = ArrayList<Key>()
        val ro = ArrayList<Int>()
        rows.forEachIndexed { r, row -> row.forEach { flat.add(it); ro.add(r) } }
        keys = flat
        rowOf = ro.toIntArray()
        rowCount = rows.size
        cancelPresses()
        refreshLabels()
        computeRects()
        invalidate()
    }

    fun setShift(state: Int) {
        shift = state
        refreshLabels()
        invalidate()
    }

    fun clearAnimations() {
        engine.clear()
        cancelPresses()
        invalidate()
    }

    private fun refreshLabels() {
        labels = Array(keys.size) { i ->
            val k = keys[i]
            when {
                k.type == KeyType.CHAR && shift != 0 -> k.label.uppercase()
                k.type == KeyType.SHIFT -> if (shift == 2) "\u21EA" else "\u21E7"
                else -> k.label
            }
        }
    }

    private fun updateShader() {
        shader = if (height > 0)
            LinearGradient(0f, 0f, 0f, height.toFloat(), theme.bgTop, theme.bgBottom, Shader.TileMode.CLAMP)
        else null
    }

    // ---------- measuring ----------

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val w = MeasureSpec.getSize(widthSpec)
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val rowH = dp * (if (land) 40f else 52f) * heightScale
        setMeasuredDimension(w, (rowH * rowCount + 8f * dp).toInt())
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        updateShader()
        computeRects()
    }

    private fun computeRects() {
        rects.clear()
        if (width == 0 || keys.isEmpty()) return
        val pad = 4f * dp
        val rowH = (height - 2 * pad) / rowCount
        var i = 0
        for (r in 0 until rowCount) {
            var total = 0f
            var j = i
            while (j < keys.size && rowOf[j] == r) { total += keys[j].weight; j++ }
            var x = pad
            val avail = width - 2 * pad
            while (i < j) {
                val w = avail * keys[i].weight / total
                rects.add(RectF(x, pad + r * rowH, x + w, pad + (r + 1) * rowH))
                x += w
                i++
            }
        }
    }

    // ---------- touch ----------

    /** Nearest non-spacer key; forgiving of gaps, edges and spacers. */
    private fun hit(x: Float, y: Float): Int {
        if (rects.size != keys.size) return -1
        val yy = y.coerceIn(0f, height - 1f)
        var best = -1
        var bestD = Float.MAX_VALUE
        for (i in rects.indices) {
            if (keys[i].type == KeyType.SPACER) continue
            val r = rects[i]
            val dy = if (yy < r.top) r.top - yy else if (yy > r.bottom) yy - r.bottom else 0f
            val dx = if (x < r.left) r.left - x else if (x > r.right) x - r.right else 0f
            val d = dx * dx + dy * dy
            if (d < bestD) { bestD = d; best = i }
        }
        return best
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                down(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_MOVE -> for (i in 0 until e.pointerCount) move(e.getPointerId(i), e.getX(i), e.getY(i))
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> up(e.getPointerId(e.actionIndex))
            MotionEvent.ACTION_CANCEL -> cancelPresses()
        }
        return true
    }

    private fun feedback() {
        if (haptic) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        if (sound) audio.playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD, 1f)
    }

    private fun down(id: Int, x: Float, y: Float) {
        val i = hit(x, y)
        if (i < 0) return
        val key = keys[i]
        val p = Press(i, x)
        presses.put(id, p)
        feedback()
        engine.start(i, x, y, SystemClock.uptimeMillis())
        when (key.type) {
            KeyType.BACKSPACE -> {
                listener?.onBackspace()
                p.fired = true
                val r = object : Runnable {
                    override fun run() {
                        listener?.onBackspace()
                        postDelayed(this, 45)
                    }
                }
                p.repeatRun = r
                postDelayed(r, 400)
            }
            KeyType.SPACE -> {
                val r = Runnable { if (!p.moved) { p.fired = true; listener?.onSpaceLong() } }
                p.longRun = r
                postDelayed(r, 550)
            }
            KeyType.CHAR -> if (key.alt != null) {
                val r = Runnable { p.fired = true; feedback(); listener?.onKey(keys[p.index], true) }
                p.longRun = r
                postDelayed(r, 380)
            }
            else -> {}
        }
        invalidate()
    }

    private fun move(id: Int, x: Float, y: Float) {
        val p = presses.get(id) ?: return
        val k = keys[p.index]
        if (k.type == KeyType.SPACE) {
            // slide on space bar = move cursor
            p.accum += x - p.lastX
            p.lastX = x
            val step = 22f * dp
            while (abs(p.accum) > step) {
                p.moved = true
                p.longRun?.let { removeCallbacks(it) }
                val dir = if (p.accum > 0) 1 else -1
                listener?.onCursor(dir)
                p.accum -= dir * step
            }
        } else if (k.type != KeyType.BACKSPACE) {
            val ni = hit(x, y)
            if (ni >= 0 && ni != p.index) {
                p.index = ni
                p.longRun?.let { removeCallbacks(it) }
                p.longRun = null
                invalidate()
            }
        }
    }

    private fun up(id: Int) {
        val p = presses.get(id) ?: return
        presses.remove(id)
        p.longRun?.let { removeCallbacks(it) }
        p.repeatRun?.let { removeCallbacks(it) }
        if (!p.fired && !p.moved) listener?.onKey(keys[p.index], false)
        invalidate()
    }

    private fun cancelPresses() {
        for (i in 0 until presses.size()) {
            val p = presses.valueAt(i)
            p.longRun?.let { removeCallbacks(it) }
            p.repeatRun?.let { removeCallbacks(it) }
        }
        presses.clear()
    }

    private fun isHeld(index: Int): Boolean {
        for (i in 0 until presses.size()) if (presses.valueAt(i).index == index) return true
        return false
    }

    override fun onDetachedFromWindow() {
        cancelPresses()
        super.onDetachedFromWindow()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE) invalidate() else clearAnimations()
    }

    // ---------- drawing ----------

    private fun withAlpha(color: Int, a: Int) = (color and 0x00FFFFFF) or (a shl 24)
    private fun contrastOn(c: Int) = if (ColorUtils.calculateLuminance(c) > 0.55) 0xFF111111.toInt() else Color.WHITE

    private fun rgbColor(now: Long, frac: Float): Int {
        hsv[0] = ((now / 9L).toFloat() + frac * 240f) % 360f
        hsv[1] = 0.9f
        hsv[2] = 1f
        return Color.HSVToColor(hsv)
    }

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val w = width.toFloat()
        val h = height.toFloat()
        bg.shader = shader
        c.drawRect(0f, 0f, w, h, bg)
        if (theme.grid) {
            gridP.color = withAlpha(theme.accent, 22)
            var gx = 0f
            while (gx < w) { c.drawLine(gx, 0f, gx, h, gridP); gx += 28f * dp }
            var gy = 0f
            while (gy < h) { c.drawLine(0f, gy, w, gy, gridP); gy += 28f * dp }
        }
        if (rects.size != keys.size || keys.isEmpty()) return

        val gap = gapDp * dp / 2f
        val rad = theme.radiusDp * radiusScale * dp
        val rowH = (h - 8f * dp) / rowCount
        val rgbNow = theme.rgb && !reduced

        for (i in keys.indices) {
            val key = keys[i]
            if (key.type == KeyType.SPACER) continue
            tmp.set(rects[i])
            tmp.inset(gap, gap)
            val accent = if (rgbNow) rgbColor(now, tmp.centerX() / w) else theme.accent
            val special = key.type != KeyType.CHAR && key.type != KeyType.SPACE
            val fill = when {
                key.type == KeyType.ENTER -> accent
                isHeld(i) -> theme.keyPressed
                special -> theme.special
                else -> theme.key
            }
            val border = if (rgbNow) accent else theme.border

            if (theme.raised) {
                face.color = ColorUtils.blendARGB(fill, Color.BLACK, 0.55f)
                c.drawRoundRect(tmp.left, tmp.top + 3.5f * dp, tmp.right, tmp.bottom + 3.5f * dp, rad, rad, face)
            }

            engine.transform(i, now, dp, xf)
            c.save()
            c.translate(0f, xf[1])
            c.scale(xf[0], xf[0], tmp.centerX(), tmp.centerY())

            face.color = fill
            c.drawRoundRect(tmp, rad, rad, face)
            if (theme.raised) {
                stroke.strokeWidth = 1f * dp
                stroke.color = withAlpha(Color.WHITE, 60)
                c.drawRoundRect(tmp, rad, rad, stroke)
            }
            if (border != 0) {
                if (theme.glowBorder && glow) {
                    stroke.strokeWidth = 4f * dp
                    stroke.color = border
                    stroke.alpha = 45
                    c.drawRoundRect(tmp, rad, rad, stroke)
                }
                stroke.strokeWidth = 1.3f * dp
                stroke.color = border
                if (theme.glowBorder) stroke.alpha = 230
                c.drawRoundRect(tmp, rad, rad, stroke)
            }

            engine.drawInside(c, tmp, rad, i, now, accent, fx, path, dp)

            // label is drawn last, on top of any effect
            val label = labels[i]
            if (key.type == KeyType.SPACE) {
                textP.textSize = rowH * 0.2f * labelScale
                textP.color = theme.hint
                c.drawText("WORDZ", tmp.centerX(), tmp.centerY() - (textP.ascent() + textP.descent()) / 2f, textP)
            } else {
                textP.textSize = rowH * (if (label.length > 1) 0.26f else 0.38f) * labelScale
                textP.color = if (key.type == KeyType.ENTER) contrastOn(accent) else theme.text
                c.drawText(label, tmp.centerX(), tmp.centerY() - (textP.ascent() + textP.descent()) / 2f, textP)
            }
            if (key.alt != null && key.type == KeyType.CHAR) {
                hintP.textSize = rowH * 0.2f * labelScale
                hintP.color = theme.hint
                c.drawText(key.alt, tmp.right - 5f * dp, tmp.top + hintP.textSize + 2f * dp, hintP)
            }
            c.restore()
        }

        engine.drawOutside(c, rects, gap, rad, now, if (rgbNow) rgbColor(now, 0.5f) else theme.accent, fx, tmp, dp)

        if (engine.active(now)) postInvalidateOnAnimation()
        else if (rgbNow && windowVisibility == VISIBLE && isAttachedToWindow) postInvalidateDelayed(40)
    }
}
