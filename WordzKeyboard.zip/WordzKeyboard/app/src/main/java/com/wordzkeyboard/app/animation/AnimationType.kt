package com.wordzkeyboard.app.animation

enum class AnimationType(val label: String) {
    SPRING_POP("Spring Pop"),
    RIPPLE("Ripple Wave"),
    NEON_FLASH("Neon Flash"),
    PARTICLE_BURST("Particle Burst"),
    PRESS_3D("3D Press"),
    SOFT_BLOOM("Soft Bloom"),
    COLOR_SPLASH("Color Splash"),
    FLOATING("Floating Key"),
    MINIMAL("Minimal Press"),
    NONE("Off")
}
