package com.wordzkeyboard.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.text.format.DateUtils
import android.view.inputmethod.InputMethodManager
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.wordzkeyboard.app.K
import com.wordzkeyboard.app.WordzSettings
import com.wordzkeyboard.app.animation.AnimationType
import com.wordzkeyboard.app.clipboard.ClipStore
import com.wordzkeyboard.app.clipboard.categoryOf
import com.wordzkeyboard.app.keyboard.KeyboardView
import com.wordzkeyboard.app.keyboard.Layouts
import com.wordzkeyboard.app.themes.ThemeRegistry

@Composable
fun WordzApp(tick: Int) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF00E5FF), onPrimary = Color.Black, secondary = Color(0xFFB14CFF),
            background = Color(0xFF0B0B14), surface = Color(0xFF15152A)
        )
    ) {
        var tab by remember { mutableIntStateOf(0) }
        val tabs = listOf("Home" to "\u2302", "Themes" to "\uD83C\uDFA8", "Studio" to "\u2728", "Clips" to "\uD83D\uDCCB")
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                NavigationBar {
                    tabs.forEachIndexed { i, (name, icon) ->
                        NavigationBarItem(
                            selected = tab == i, onClick = { tab = i },
                            icon = { Text(icon) }, label = { Text(name) }
                        )
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad)) {
                when (tab) {
                    0 -> HomeScreen(tick)
                    1 -> ThemesScreen()
                    2 -> StudioScreen()
                    else -> ClipScreen()
                }
            }
        }
    }
}

@Composable
fun TestField() {
    var v by remember { mutableStateOf("") }
    OutlinedTextField(
        value = v, onValueChange = { v = it }, modifier = Modifier.fillMaxWidth(),
        label = { Text("Try the keyboard here") }
    )
}

@Composable
fun HomeScreen(tick: Int) {
    val ctx = LocalContext.current
    val s = remember { WordzSettings(ctx) }
    val imm = ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    val enabled = remember(tick) { imm.enabledInputMethodList.any { it.packageName == ctx.packageName } }
    val active = remember(tick) {
        (Settings.Secure.getString(ctx.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: "")
            .startsWith(ctx.packageName + "/")
    }
    val theme = ThemeRegistry.byId(s.str(K.THEME, "neon"))
    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("WORDZ KEYBOARD", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
        Text("Animated, customizable and private. Current theme: ${theme.name}")
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Setup", style = MaterialTheme.typography.titleMedium)
                Text(if (enabled) "\u2705 Step 1: enabled in Android settings" else "\u2B1C Step 1: enable WORDZ KEYBOARD")
                Text(if (active) "\u2705 Step 2: selected as your keyboard" else "\u2B1C Step 2: choose it as the active keyboard")
                Button(onClick = {
                    runCatching { ctx.startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                }) { Text("1. Open keyboard settings") }
                OutlinedButton(onClick = { imm.showInputMethodPicker() }) { Text("2. Choose keyboard") }
                Text("Android will show a warning that keyboards can see what you type. That is true of every keyboard, so enable only keyboards you trust.", style = MaterialTheme.typography.bodySmall)
            }
        }
        TestField()
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Privacy", style = MaterialTheme.typography.titleMedium)
                Text("\u2022 No internet permission, no analytics, no accounts.")
                Text("\u2022 Typed text is never stored. Clipboard history and snippets stay on this phone.")
                Text("\u2022 Password fields: clipboard capture and snippets are off.")
                Text("\u2022 Clipboard capture is best effort. Android only lets the active keyboard read the clipboard, so some copies can be missed.")
            }
        }
    }
}

@Composable
fun ThemesScreen() {
    val ctx = LocalContext.current
    val s = remember { WordzSettings(ctx) }
    var current by remember { mutableStateOf(s.str(K.THEME, "neon")) }
    LazyColumn(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Spacer(Modifier.height(8.dp)); Text("Themes", style = MaterialTheme.typography.headlineSmall) }
        item { TestField() }
        items(ThemeRegistry.all, key = { it.id }) { t ->
            Card(Modifier.fillMaxWidth().clickable { current = t.id; s.put(K.THEME, t.id) }) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        Modifier.fillMaxWidth().height(64.dp).clip(RoundedCornerShape(12.dp))
                            .background(Brush.verticalGradient(listOf(Color(t.bgTop), Color(t.bgBottom))))
                            .padding(10.dp)
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            repeat(6) { Box(Modifier.size(30.dp, 38.dp).clip(RoundedCornerShape(6.dp)).background(Color(t.key))) }
                            Box(Modifier.size(30.dp, 38.dp).clip(RoundedCornerShape(6.dp)).background(Color(t.accent)))
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(t.name, style = MaterialTheme.typography.titleMedium)
                        Text(if (current == t.id) "Active \u2713" else "Tap to apply")
                    }
                }
            }
        }
    }
}

@Composable
fun SliderRow(s: WordzSettings, key: String, label: String, min: Float, max: Float, def: Float, onChange: () -> Unit) {
    var v by remember { mutableFloatStateOf(s.float(key, def)) }
    Column {
        Text("$label: ${"%.2f".format(v)}")
        Slider(value = v, valueRange = min..max, onValueChange = { v = it; s.put(key, it); onChange() })
    }
}

@Composable
fun SwitchRow(s: WordzSettings, key: String, label: String, def: Boolean, onChange: () -> Unit) {
    var v by remember { mutableStateOf(s.bool(key, def)) }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked = v, onCheckedChange = { v = it; s.put(key, it); onChange() })
    }
}

@Composable
fun StudioScreen() {
    val ctx = LocalContext.current
    val s = remember { WordzSettings(ctx) }
    var ver by remember { mutableIntStateOf(0) }
    var anim by remember { mutableStateOf(s.str(K.ANIM, "auto")) }
    val bump: () -> Unit = { ver++ }
    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("Animation Studio", style = MaterialTheme.typography.headlineSmall)
        Text("This is the real keyboard view. Tap keys to compare effects.", style = MaterialTheme.typography.bodySmall)
        val v = ver
        AndroidView(
            modifier = Modifier.fillMaxWidth(),
            factory = { c -> KeyboardView(c).also { it.setLayout(Layouts.letters()) } },
            update = { view -> if (v >= 0) view.applySettings(s) }
        )
        Text("Effect", style = MaterialTheme.typography.titleMedium)
        val opts = listOf("auto" to "Auto (theme default)") + AnimationType.values().map { it.name to it.label }
        opts.forEach { (id, name) ->
            Row(
                Modifier.fillMaxWidth().clickable { anim = id; s.put(K.ANIM, id); bump() },
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(selected = anim == id, onClick = { anim = id; s.put(K.ANIM, id); bump() })
                Text(name)
            }
        }
        Text("Tuning", style = MaterialTheme.typography.titleMedium)
        SliderRow(s, K.SPEED, "Animation speed", 0.5f, 2f, 1f, bump)
        SliderRow(s, K.INTENSITY, "Animation intensity", 0.2f, 1.2f, 0.8f, bump)
        SliderRow(s, K.HEIGHT, "Keyboard height", 0.8f, 1.3f, 1f, bump)
        SliderRow(s, K.GAP, "Key spacing (dp)", 1f, 8f, 4f, bump)
        SliderRow(s, K.RADIUS, "Corner radius", 0f, 1.6f, 1f, bump)
        SliderRow(s, K.LABEL, "Label size", 0.8f, 1.4f, 1f, bump)
        SwitchRow(s, K.PARTICLES, "Particles", true, bump)
        SwitchRow(s, K.GLOW, "Glow", true, bump)
        SwitchRow(s, K.REDUCED, "Reduced motion / battery friendly", false, bump)
        SwitchRow(s, K.HAPTIC, "Haptic feedback", true, bump)
        SwitchRow(s, K.SOUND, "Key click sound (uses system key sound)", false, bump)
        TestField()
    }
}

@Composable
fun ClipScreen() {
    val ctx = LocalContext.current
    val store = remember { ClipStore.get(ctx) }
    val s = remember { WordzSettings(ctx) }
    var ver by remember { mutableIntStateOf(0) }
    var q by remember { mutableStateOf("") }
    var snips by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(false) }
    var editId by remember { mutableStateOf<Long?>(null) }
    var newText by remember { mutableStateOf("") }
    var newLabel by remember { mutableStateOf("") }
    val list = remember(ver, q, snips) { store.query(snips, "All", q) }

    LazyColumn(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!snips) Button(onClick = {}) { Text("Clipboard") } else OutlinedButton(onClick = { snips = false }) { Text("Clipboard") }
                if (snips) Button(onClick = {}) { Text("Snippets") } else OutlinedButton(onClick = { snips = true }) { Text("Snippets") }
            }
        }
        item { OutlinedTextField(value = q, onValueChange = { q = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Search") }, singleLine = true) }
        if (snips) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(value = newLabel, onValueChange = { newLabel = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Label / shortcut (optional)") }, singleLine = true)
                    OutlinedTextField(value = newText, onValueChange = { newText = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Snippet text") })
                    Button(enabled = newText.isNotBlank(), onClick = {
                        val id = editId
                        if (id == null) store.addSnippet(newText.trim(), newLabel.trim()) else store.updateSnippet(id, newText.trim(), newLabel.trim())
                        editId = null; newText = ""; newLabel = ""; ver++
                    }) { Text(if (editId == null) "Add snippet" else "Save changes") }
                }
            }
        } else {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    SwitchRow(s, K.PAUSE, "Pause clipboard history", false) {}
                    SliderRow(s, K.LIMIT, "History limit", 10f, 200f, 50f) {}
                    OutlinedButton(onClick = { confirm = true }) { Text("Clear history") }
                    Text("Capture is best effort: Android only lets the active keyboard read the clipboard, and may deny it. Sensitive-flagged copies and password fields are skipped.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        items(list, key = { it.id }) { item ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    if (item.label.isNotBlank()) Text(item.label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                    Text(item.text, maxLines = 4)
                    Text(
                        categoryOf(item.text) + " \u00B7 " + DateUtils.getRelativeTimeSpanString(item.ts, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS),
                        style = MaterialTheme.typography.bodySmall
                    )
                    Row {
                        TextButton(onClick = { store.togglePin(item.id); ver++ }) { Text(if (item.pinned) "Unpin" else "Pin") }
                        TextButton(onClick = {
                            (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("", item.text))
                        }) { Text("Copy") }
                        if (snips) TextButton(onClick = { editId = item.id; newText = item.text; newLabel = item.label }) { Text("Edit") }
                        else TextButton(onClick = { store.addSnippet(item.text, ""); ver++ }) { Text("Save as snippet") }
                        TextButton(onClick = { store.delete(item.id); ver++ }) { Text("Delete") }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }

    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("Clear clipboard history?") },
        text = { Text("Pinned items are kept. Snippets are not affected. This cannot be undone.") },
        confirmButton = { TextButton(onClick = { store.clearClips(true); confirm = false; ver++ }) { Text("Clear") } },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } }
    )
}
