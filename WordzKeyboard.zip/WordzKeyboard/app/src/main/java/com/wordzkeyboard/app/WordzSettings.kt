package com.wordzkeyboard.app

import android.content.Context
import android.content.SharedPreferences

object K {
    const val THEME = "theme"
    const val ANIM = "anim"
    const val SPEED = "speed"
    const val INTENSITY = "intensity"
    const val HEIGHT = "height"
    const val GAP = "gap"
    const val RADIUS = "radius"
    const val LABEL = "label"
    const val HAPTIC = "haptic"
    const val SOUND = "sound"
    const val REDUCED = "reduced"
    const val PARTICLES = "particles"
    const val GLOW = "glow"
    const val PAUSE = "pause"
    const val LIMIT = "limit"
}

class WordzSettings(context: Context) {
    private val p: SharedPreferences =
        context.applicationContext.getSharedPreferences("wordz_settings", Context.MODE_PRIVATE)

    fun str(k: String, d: String): String = p.getString(k, d) ?: d
    fun float(k: String, d: Float): Float = p.getFloat(k, d)
    fun bool(k: String, d: Boolean): Boolean = p.getBoolean(k, d)
    fun put(k: String, v: String) { p.edit().putString(k, v).apply() }
    fun put(k: String, v: Float) { p.edit().putFloat(k, v).apply() }
    fun put(k: String, v: Boolean) { p.edit().putBoolean(k, v).apply() }
}
