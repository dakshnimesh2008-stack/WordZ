package com.wordzkeyboard.app.clipboard

import android.content.Context
import android.util.Patterns
import org.json.JSONArray
import org.json.JSONObject

data class ClipItem(
    val id: Long,
    val text: String,
    val pinned: Boolean,
    val ts: Long,
    val snippet: Boolean,
    val label: String
)

fun categoryOf(text: String): String = when {
    Patterns.EMAIL_ADDRESS.matcher(text).find() -> "Emails"
    Patterns.WEB_URL.matcher(text).find() -> "Links"
    else -> "Notes"
}

/**
 * Local-only store (app-private SharedPreferences, JSON). Holds both clipboard history
 * and user snippets. Swap for Room later if you need larger histories.
 */
class ClipStore private constructor(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("wordz_clips", Context.MODE_PRIVATE)
    private val items = ArrayList<ClipItem>()

    init {
        val raw = prefs.getString("items", null)
        if (raw != null) {
            try {
                val a = JSONArray(raw)
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    items.add(
                        ClipItem(
                            o.getLong("id"), o.getString("text"), o.optBoolean("pinned"),
                            o.optLong("ts"), o.optBoolean("snippet"), o.optString("label")
                        )
                    )
                }
            } catch (e: Exception) { /* corrupt store: start empty, never log content */ }
        }
    }

    private fun persist() {
        val a = JSONArray()
        items.forEach {
            a.put(
                JSONObject().put("id", it.id).put("text", it.text).put("pinned", it.pinned)
                    .put("ts", it.ts).put("snippet", it.snippet).put("label", it.label)
            )
        }
        prefs.edit().putString("items", a.toString()).apply()
    }

    @Synchronized
    fun addClip(text: String, limit: Int) {
        val now = System.currentTimeMillis()
        val i = items.indexOfFirst { !it.snippet && it.text == text }
        if (i >= 0) items[i] = items[i].copy(ts = now)
        else items.add(ClipItem(System.nanoTime(), text, false, now, false, ""))
        val unpinned = items.filter { !it.snippet && !it.pinned }.sortedByDescending { it.ts }
        if (unpinned.size > limit) items.removeAll(unpinned.drop(limit).toSet())
        persist()
    }

    @Synchronized
    fun addSnippet(text: String, label: String) {
        items.add(ClipItem(System.nanoTime(), text, false, System.currentTimeMillis(), true, label))
        persist()
    }

    @Synchronized
    fun updateSnippet(id: Long, text: String, label: String) {
        val i = items.indexOfFirst { it.id == id }
        if (i >= 0) { items[i] = items[i].copy(text = text, label = label); persist() }
    }

    @Synchronized
    fun togglePin(id: Long) {
        val i = items.indexOfFirst { it.id == id }
        if (i >= 0) { items[i] = items[i].copy(pinned = !items[i].pinned); persist() }
    }

    @Synchronized
    fun delete(id: Long) {
        items.removeAll { it.id == id }
        persist()
    }

    /** Removes clipboard history (never snippets). */
    @Synchronized
    fun clearClips(keepPinned: Boolean) {
        items.removeAll { !it.snippet && !(keepPinned && it.pinned) }
        persist()
    }

    @Synchronized
    fun query(snippet: Boolean, filter: String, q: String): List<ClipItem> {
        val needle = q.trim().lowercase()
        return items.filter { it.snippet == snippet }
            .filter {
                when (filter) {
                    "Pinned" -> it.pinned
                    "Links", "Emails", "Notes" -> categoryOf(it.text) == filter
                    else -> true
                }
            }
            .filter { needle.isEmpty() || it.text.lowercase().contains(needle) || it.label.lowercase().contains(needle) }
            .sortedWith(compareByDescending<ClipItem> { it.pinned }.thenByDescending { it.ts })
    }

    companion object {
        @Volatile private var inst: ClipStore? = null
        fun get(context: Context): ClipStore =
            inst ?: synchronized(this) { inst ?: ClipStore(context).also { inst = it } }
    }
}
