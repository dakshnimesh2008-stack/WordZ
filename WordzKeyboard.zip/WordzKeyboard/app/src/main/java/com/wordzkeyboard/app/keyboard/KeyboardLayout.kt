package com.wordzkeyboard.app.keyboard

enum class KeyType { CHAR, SHIFT, BACKSPACE, SPACE, ENTER, SYMBOLS, LETTERS, MORE, SPACER }

data class Key(
    val label: String,
    val type: KeyType = KeyType.CHAR,
    val weight: Float = 1f,
    val alt: String? = null
)

/** English QWERTY + two symbol pages. Every row's weights sum to 10. */
object Layouts {
    private fun chars(s: String, alts: String? = null): List<Key> =
        s.mapIndexed { i, ch -> Key(ch.toString(), KeyType.CHAR, 1f, alts?.getOrNull(i)?.toString()) }

    private fun spacer() = Key("", KeyType.SPACER, 0.5f)

    private fun bottom(left: Key, second: String, third: String, enter: String) = listOf(
        left, Key(second), Key(" ", KeyType.SPACE, 5f), Key(third), Key(enter, KeyType.ENTER, 1.5f)
    )

    fun letters(second: String = ",", third: String = ".", enter: String = "\u21B5"): List<List<Key>> = listOf(
        chars("qwertyuiop", "1234567890"),
        listOf(spacer()) + chars("asdfghjkl", "@#\$%&-+()") + spacer(),
        listOf(Key("\u21E7", KeyType.SHIFT, 1.5f)) + chars("zxcvbnm", "*\"':;!?") +
            Key("\u232B", KeyType.BACKSPACE, 1.5f),
        bottom(Key("?123", KeyType.SYMBOLS, 1.5f), second, third, enter)
    )

    fun symbols(page: Int, enter: String = "\u21B5"): List<List<Key>> {
        val back = Key("ABC", KeyType.LETTERS, 1.5f)
        val bs = Key("\u232B", KeyType.BACKSPACE, 1.5f)
        return if (page == 0) listOf(
            chars("1234567890"),
            listOf(spacer()) + chars("@#\$%&-+()") + spacer(),
            listOf(Key("=<", KeyType.MORE, 1.5f)) + chars("*\"':;!?") + bs,
            bottom(back, ",", ".", enter)
        ) else listOf(
            chars("[]{}#%^*+="),
            listOf(spacer()) + chars("_\\|~<>\u20AC\u00A3\u00A5") + spacer(),
            listOf(Key("1/2", KeyType.MORE, 1.5f)) + chars("\u2022.,?!'\"") + bs,
            bottom(back, ",", ".", enter)
        )
    }
}
