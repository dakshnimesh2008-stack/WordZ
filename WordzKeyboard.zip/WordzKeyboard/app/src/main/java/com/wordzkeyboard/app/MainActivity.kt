package com.wordzkeyboard.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import com.wordzkeyboard.app.ui.WordzApp

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WordzApp(tick) }
    }

    override fun onResume() {
        super.onResume()
        tick++   // re-check keyboard enabled/selected state after returning from system settings
    }
}
