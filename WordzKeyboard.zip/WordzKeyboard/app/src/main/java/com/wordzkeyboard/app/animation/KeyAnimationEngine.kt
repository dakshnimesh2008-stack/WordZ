package com.wordzkeyboard.app.animation

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.sin
import kotlin.math.sqrt

private const val PI_F = 3.1415927f

/**
 * Allocation-free keypress effects. A fixed ring of slots stores recent presses;
 * the view asks for transforms / overlays each frame. Labels are always drawn by
 * the view AFTER inside-overlays, and overlay alphas are capped, so an effect can
 * never hide a label.
 */
class KeyAnimationEngine {
    var type = AnimationType.MINIMAL
    var speed = 1f
    var intensity = 0.8f
    var particles = true
    var glow = true
    var reduced = false

    private val n = 16
    private val idx = IntArray(n) { -1 }
    private val px = FloatArray(n)
    private val py = FloatArray(n)
    private val t0 = LongArray(n)
    private var head = 0
    private val cosA = FloatArray(7) { cos(it * 2f * PI_F / 7f) }
    private val sinA = FloatArray(7) { sin(it * 2f * PI_F / 7f) }

    private val eff: AnimationType
        get() = if (reduced && type != AnimationType.NONE) AnimationType.MINIMAL else type
    private val dur: Float get() = (190f / speed).coerceIn(80f, 420f)

    fun start(index: Int, x: Float, y: Float, now: Long) {
        if (eff == AnimationType.NONE) return
        idx[head] = index; px[head] = x; py[head] = y; t0[head] = now
        head = (head + 1) % n
    }

    fun clear() { idx.fill(-1) }

    private fun prog(slot: Int, now: Long): Float {
        if (idx[slot] < 0) return -1f
        val t = (now - t0[slot]) / dur
        if (t >= 1f) { idx[slot] = -1; return -1f }
        return t.coerceAtLeast(0f)
    }

    fun active(now: Long): Boolean {
        for (i in 0 until n) if (prog(i, now) >= 0f) return true
        return false
    }

    private fun slotFor(index: Int, now: Long): Int {
        var best = -1
        for (i in 0 until n) {
            if (idx[i] == index && prog(i, now) >= 0f && (best < 0 || t0[i] > t0[best])) best = i
        }
        return best
    }

    /** out[0] = scale, out[1] = vertical offset in px */
    fun transform(index: Int, now: Long, dp: Float, out: FloatArray) {
        out[0] = 1f; out[1] = 0f
        val s = slotFor(index, now)
        if (s < 0) return
        val t = prog(s, now)
        val a = intensity
        when (eff) {
            AnimationType.SPRING_POP -> out[0] = 1f - 0.14f * a * exp(-4f * t) * cos(7f * t)
            AnimationType.PRESS_3D -> {
                val k = 1f - t
                out[0] = 1f - 0.04f * a * k
                out[1] = 3.5f * dp * a * k * k
            }
            AnimationType.FLOATING -> {
                val w = sin(PI_F * t)
                out[1] = -4f * dp * a * w
                out[0] = 1f + 0.05f * a * w
            }
            AnimationType.MINIMAL -> out[0] = 1f - 0.05f * a * (1f - t)
            AnimationType.NONE -> {}
            else -> out[0] = 1f - 0.03f * a * (1f - t)
        }
    }

    /** Effects that live inside the key face (clipped / tinted). */
    fun drawInside(
        c: Canvas, r: RectF, rad: Float, index: Int, now: Long,
        accent: Int, p: Paint, path: Path, dp: Float
    ) {
        val s = slotFor(index, now)
        if (s < 0) return
        val t = prog(s, now)
        val a = intensity
        val inv = 1f - t
        when (eff) {
            AnimationType.RIPPLE -> {
                path.reset()
                path.addRoundRect(r, rad, rad, Path.Direction.CW)
                c.save()
                c.clipPath(path)
                p.style = Paint.Style.FILL
                p.color = accent
                p.alpha = (inv * 120f * a).toInt().coerceIn(0, 140)
                c.drawCircle(px[s], py[s], r.width() * 0.95f * sqrt(t), p)
                c.restore()
            }
            AnimationType.COLOR_SPLASH -> {
                p.style = Paint.Style.FILL
                p.color = accent
                p.alpha = (inv * 150f * a).toInt().coerceIn(0, 150)
                c.drawRoundRect(r, rad, rad, p)
            }
            AnimationType.NEON_FLASH -> {
                p.style = Paint.Style.FILL
                p.color = accent
                p.alpha = (inv * 60f * a).toInt().coerceIn(0, 80)
                c.drawRoundRect(r, rad, rad, p)
                if (glow) {
                    p.style = Paint.Style.STROKE
                    p.strokeWidth = 2f * dp
                    p.alpha = (inv * 255f).toInt().coerceIn(0, 255)
                    c.drawRoundRect(r, rad, rad, p)
                }
            }
            AnimationType.SOFT_BLOOM -> {
                p.style = Paint.Style.FILL
                p.color = accent
                p.alpha = (inv * 50f * a).toInt().coerceIn(0, 70)
                c.drawRoundRect(r, rad, rad, p)
            }
            else -> {}
        }
    }

    /** Effects that extend outside the key (particles, bloom rings). Drawn after all keys. */
    fun drawOutside(
        c: Canvas, rects: List<RectF>, inset: Float, rad: Float, now: Long,
        accent: Int, p: Paint, tmp: RectF, dp: Float
    ) {
        val e = eff
        if (e != AnimationType.PARTICLE_BURST && e != AnimationType.NEON_FLASH && e != AnimationType.SOFT_BLOOM) return
        if (e == AnimationType.PARTICLE_BURST && !particles) return
        if (e != AnimationType.PARTICLE_BURST && !glow) return
        for (s in 0 until n) {
            val t = prog(s, now)
            if (t < 0f) continue
            val r = rects.getOrNull(idx[s]) ?: continue
            val inv = 1f - t
            p.color = accent
            if (e == AnimationType.PARTICLE_BURST) {
                p.style = Paint.Style.FILL
                p.alpha = (inv * 230f * intensity).toInt().coerceIn(0, 255)
                val d = r.width() * 0.6f * (1f - inv * inv)
                val rr = dp * (2.4f * inv + 0.6f)
                for (i in 0 until 7) c.drawCircle(r.centerX() + cosA[i] * d, r.centerY() + sinA[i] * d, rr, p)
            } else {
                val grow = 2f * dp + 6f * dp * t
                tmp.set(r)
                tmp.inset(inset - grow, inset - grow)
                p.style = Paint.Style.STROKE
                p.strokeWidth = 2f * dp
                val base = if (e == AnimationType.NEON_FLASH) 160f else 80f
                p.alpha = (inv * base * intensity).toInt().coerceIn(0, 200)
                c.drawRoundRect(tmp, rad + grow, rad + grow, p)
            }
        }
    }
}
