package com.wordzkeyboard.app.keyboard

import android.content.Context
import android.graphics.Color
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.wordzkeyboard.app.clipboard.ClipItem
import com.wordzkeyboard.app.clipboard.ClipStore
import com.wordzkeyboard.app.clipboard.categoryOf
import com.wordzkeyboard.app.themes.KeyboardTheme

private const val EMOJI =
    "😀 😁 😂 🤣 😊 😍 😘 😎 🤔 😅 😢 😭 😡 🥳 😴 🙄 😉 🙂 🙃 😇 🤗 😬 😱 🤯 " +
    "👍 👎 👏 🙌 🙏 💪 👌 ✌ 🤞 👋 🤝 ❤ 🧡 💛 💚 💙 💜 🖤 💔 ✨ 🔥 🎉 🎂 🎁 " +
    "💯 ✅ ❌ ⭐ 🌟 ☀ 🌙 ☕ 🍕 🍔 🍟 🍿 🍫 🍎 🐶 🐱 🐼 🌹 🌈 ⚡ 💡 📌 📞 " +
    "💬 📷 🚀 ✈ 🏠 ⚽ 🎵 🎮 💻 📱 ⏰ 🙈"

/** Clipboard / Snippets / Emoji panel shown in place of the keys. */
class PanelView(context: Context) : LinearLayout(context) {
    var onBack: (() -> Unit)? = null

    private val dp = resources.displayMetrics.density
    private var fg = Color.WHITE
    private var accent = Color.CYAN
    private val backBtn = TextView(context)
    private val titleV = TextView(context)
    private val actionV = TextView(context)
    private val body = ScrollView(context)

    init {
        orientation = VERTICAL
        val header = LinearLayout(context).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        listOf(backBtn, actionV).forEach {
            it.gravity = Gravity.CENTER
            it.setPadding((14 * dp).toInt(), 0, (14 * dp).toInt(), 0)
            it.textSize = 14f
            it.minHeight = (44 * dp).toInt()
        }
        backBtn.text = "ABC"
        backBtn.contentDescription = "Back to keyboard"
        backBtn.setOnClickListener { onBack?.invoke() }
        titleV.gravity = Gravity.CENTER
        titleV.textSize = 15f
        header.addView(backBtn, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.MATCH_PARENT))
        header.addView(titleV, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        header.addView(actionV, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.MATCH_PARENT))
        addView(header, LayoutParams(LayoutParams.MATCH_PARENT, (40 * dp).toInt()))
        addView(body, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
    }

    fun applyTheme(t: KeyboardTheme) {
        fg = t.text
        accent = t.accent
        setBackgroundColor(t.bgBottom or (0xFF shl 24))
        listOf(backBtn, titleV, actionV).forEach { it.setTextColor(fg) }
    }

    private fun tv(text: String, sp: Float, alpha: Int = 255): TextView = TextView(context).apply {
        this.text = text
        textSize = sp
        setTextColor(fg)
        this.alpha = alpha / 255f
    }

    private fun col(): LinearLayout = LinearLayout(context).apply {
        orientation = VERTICAL
        setPadding((8 * dp).toInt(), (4 * dp).toInt(), (8 * dp).toInt(), (8 * dp).toInt())
    }

    private fun itemRow(
        item: ClipItem, onClick: () -> Unit, onLong: (() -> Unit)?, onPin: (() -> Unit)?, onDelete: () -> Unit
    ): View {
        val r = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((12 * dp).toInt(), (4 * dp).toInt(), 0, (4 * dp).toInt())
            setBackgroundColor((fg and 0x00FFFFFF) or (0x1E shl 24))
        }
        val c = LinearLayout(context).apply { orientation = VERTICAL }
        if (item.label.isNotBlank()) c.addView(tv(item.label, 11f, 170))
        c.addView(tv(item.text, 14f).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END })
        r.addView(c, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        if (onPin != null) {
            r.addView(tv(if (item.pinned) "★" else "☆", 18f).apply {
                gravity = Gravity.CENTER
                minWidth = (44 * dp).toInt(); minHeight = (44 * dp).toInt()
                contentDescription = if (item.pinned) "Unpin" else "Pin"
                setOnClickListener { onPin() }
            })
        }
        r.addView(tv("✕", 16f).apply {
            gravity = Gravity.CENTER
            minWidth = (44 * dp).toInt(); minHeight = (44 * dp).toInt()
            contentDescription = "Delete"
            setOnClickListener { onDelete() }
        })
        r.setOnClickListener { onClick() }
        if (onLong != null) r.setOnLongClickListener { onLong(); true }
        r.layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { bottomMargin = (4 * dp).toInt() }
        return r
    }

    fun showClipboard(store: ClipStore, onInsert: (String) -> Unit) {
        titleV.text = "Clipboard"
        actionV.text = "Clear"
        actionV.contentDescription = "Clear history, pinned items are kept"
        var filter = "All"
        var armed = false

        fun render() {
            body.removeAllViews()
            val list = col()
            val chips = LinearLayout(context).apply { orientation = HORIZONTAL }
            for (f in listOf("All", "Pinned", "Links", "Emails", "Notes")) {
                chips.addView(tv(f, 12f, if (f == filter) 255 else 150).apply {
                    setPadding((10 * dp).toInt(), (8 * dp).toInt(), (10 * dp).toInt(), (8 * dp).toInt())
                    setOnClickListener { filter = f; render() }
                })
            }
            list.addView(chips)
            val items = store.query(false, filter, "")
            if (items.isEmpty()) {
                list.addView(tv("Nothing here yet. Text you copy while WORDZ is your active keyboard appears here. Android may block capture in some cases.", 12f, 170).apply { setPadding(0, (8 * dp).toInt(), 0, 0) })
            }
            items.forEach { it0 ->
                list.addView(itemRow(
                    it0,
                    onClick = { onInsert(it0.text) },
                    onLong = { store.addSnippet(it0.text, categoryOf(it0.text)); Toast.makeText(context, "Saved as snippet", Toast.LENGTH_SHORT).show() },
                    onPin = { store.togglePin(it0.id); render() },
                    onDelete = { store.delete(it0.id); render() }
                ))
            }
            body.addView(list)
        }
        actionV.setOnClickListener {
            if (armed) { store.clearClips(true); armed = false; actionV.text = "Clear"; render() }
            else { armed = true; actionV.text = "Tap again" }
        }
        render()
    }

    fun showSnippets(store: ClipStore, onInsert: (String) -> Unit, onManage: () -> Unit) {
        titleV.text = "Snippets"
        actionV.text = "Manage"
        actionV.contentDescription = "Open WORDZ to manage snippets"
        actionV.setOnClickListener { onManage() }
        fun render() {
            body.removeAllViews()
            val list = col()
            val items = store.query(true, "All", "")
            if (items.isEmpty()) list.addView(tv("No snippets yet. Long-press a clipboard item to save it, or tap Manage to create one.", 12f, 170))
            items.forEach { s ->
                list.addView(itemRow(s, onClick = { onInsert(s.text) }, onLong = null,
                    onPin = { store.togglePin(s.id); render() }, onDelete = { store.delete(s.id); render() }))
            }
            body.addView(list)
        }
        render()
    }

    fun showEmoji(onInsert: (String) -> Unit) {
        titleV.text = "Emoji"
        actionV.text = ""
        actionV.setOnClickListener(null)
        body.removeAllViews()
        val grid = GridLayout(context).apply { columnCount = 8 }
        EMOJI.split(" ").forEach { e ->
            val cell = TextView(context).apply {
                text = e; textSize = 24f; gravity = Gravity.CENTER
                contentDescription = e
                setOnClickListener { onInsert(e) }
            }
            val lp = GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED, 1f), GridLayout.spec(GridLayout.UNDEFINED, 1f))
            lp.width = 0
            lp.height = (44 * dp).toInt()
            grid.addView(cell, lp)
        }
        body.addView(grid)
    }
}
