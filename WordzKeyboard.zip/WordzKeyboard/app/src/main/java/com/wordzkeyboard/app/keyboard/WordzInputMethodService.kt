package com.wordzkeyboard.app.keyboard

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.inputmethodservice.InputMethodService
import android.os.SystemClock
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.wordzkeyboard.app.K
import com.wordzkeyboard.app.MainActivity
import com.wordzkeyboard.app.WordzSettings
import com.wordzkeyboard.app.clipboard.ClipStore
import com.wordzkeyboard.app.themes.ThemeRegistry

class WordzInputMethodService : InputMethodService(), KeyboardView.Listener {

    private lateinit var settings: WordzSettings
    private lateinit var store: ClipStore
    private lateinit var root: LinearLayout
    private lateinit var toolbar: LinearLayout
    private lateinit var keyView: KeyboardView
    private lateinit var panel: PanelView
    private val toolButtons = ArrayList<TextView>()
    private var clipBtn: TextView? = null
    private var snipBtn: TextView? = null

    private var shift = 0              // 0 off, 1 once, 2 caps lock
    private var lastShiftTap = 0L
    private var mode = 0               // 0 letters, 1 symbols, 2 more symbols
    private var numeric = false
    private var password = false
    private var autoCap = false
    private var second = ","
    private var third = "."
    private var enterLabel = "\u21B5"

    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener { captureClipboard() }

    override fun onCreate() {
        super.onCreate()
        settings = WordzSettings(this)
        store = ClipStore.get(this)
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).addPrimaryClipChangedListener(clipListener)
    }

    override fun onDestroy() {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).removePrimaryClipChangedListener(clipListener)
        super.onDestroy()
    }

    override fun onEvaluateFullscreenMode() = false

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (::keyView.isInitialized) keyView.requestLayout()
    }

    override fun onCreateInputView(): View {
        keyView = KeyboardView(this).apply { listener = this@WordzInputMethodService }
        panel = PanelView(this).apply { visibility = View.GONE; onBack = { showKeys() } }
        val content = FrameLayout(this)
        content.addView(keyView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        content.addView(panel, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        toolbar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        toolButtons.clear()
        clipBtn = addTool("\uD83D\uDCCB", "Clipboard history") { showClipboard() }
        snipBtn = addTool("\uD83D\uDCDD", "Snippets") { showSnippets() }
        addTool("\uD83C\uDFA8", "Change theme") { cycleTheme() }
        addTool("\uD83D\uDE00", "Emoji") { showEmoji() }
        addTool("\u2699", "Keyboard settings") { openSettings() }

        val d = resources.displayMetrics.density
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(toolbar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (40 * d).toInt()))
        root.addView(content, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        applyAll()
        refreshLayout()
        return root
    }

    private fun addTool(glyph: String, desc: String, action: () -> Unit): TextView {
        val b = TextView(this).apply {
            text = glyph; textSize = 18f; gravity = Gravity.CENTER
            contentDescription = desc
            setOnClickListener { action() }
        }
        toolbar.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        toolButtons.add(b)
        return b
    }

    private fun applyAll() {
        keyView.applySettings(settings)
        val t = ThemeRegistry.byId(settings.str(K.THEME, "neon"))
        toolbar.setBackgroundColor(t.bgTop or (0xFF shl 24))
        root.setBackgroundColor(t.bgBottom or (0xFF shl 24))
        toolButtons.forEach { it.setTextColor(t.text) }
        panel.applyTheme(t)
    }

    // ---------- editor handling ----------

    override fun onStartInputView(info: EditorInfo, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        val type = info.inputType
        val cls = type and InputType.TYPE_MASK_CLASS
        val v = type and InputType.TYPE_MASK_VARIATION
        val isText = cls == InputType.TYPE_CLASS_TEXT
        password = (isText && (v == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
            v == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
            v == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD)) ||
            (cls == InputType.TYPE_CLASS_NUMBER && v == InputType.TYPE_NUMBER_VARIATION_PASSWORD)
        numeric = cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE || cls == InputType.TYPE_CLASS_DATETIME
        second = when {
            isText && (v == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS || v == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS) -> "@"
            isText && v == InputType.TYPE_TEXT_VARIATION_URI -> "/"
            else -> ","
        }
        autoCap = isText && !password &&
            (type and (InputType.TYPE_TEXT_FLAG_CAP_SENTENCES or InputType.TYPE_TEXT_FLAG_CAP_WORDS or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS)) != 0
        val noEnterAction = (info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        enterLabel = if (noEnterAction) "\u21B5" else when (info.imeOptions and EditorInfo.IME_MASK_ACTION) {
            EditorInfo.IME_ACTION_SEARCH -> "Search"
            EditorInfo.IME_ACTION_GO -> "Go"
            EditorInfo.IME_ACTION_SEND -> "Send"
            EditorInfo.IME_ACTION_NEXT -> "Next"
            EditorInfo.IME_ACTION_DONE -> "Done"
            else -> "\u21B5"
        }
        mode = 0
        shift = 0
        // clipboard / snippets are hidden in password fields
        val vis = if (password) View.GONE else View.VISIBLE
        clipBtn?.visibility = vis
        snipBtn?.visibility = vis
        applyAll()
        showKeys()
        refreshLayout()
        updateAutoCaps()
        captureClipboard()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        if (::keyView.isInitialized) { keyView.clearAnimations(); showKeys() }
    }

    override fun onWindowHidden() {
        super.onWindowHidden()
        if (::keyView.isInitialized) keyView.clearAnimations()
    }

    private fun refreshLayout() {
        val rows = when {
            numeric -> Layouts.symbols(0, enterLabel)
            mode == 0 -> Layouts.letters(second, third, enterLabel)
            else -> Layouts.symbols(mode - 1, enterLabel)
        }
        keyView.setLayout(rows)
        keyView.setShift(shift)
    }

    private fun updateAutoCaps() {
        if (!autoCap || shift == 2 || mode != 0) return
        val ic = currentInputConnection ?: return
        val caps = ic.getCursorCapsMode(currentInputEditorInfo?.inputType ?: 0) != 0
        val ns = if (caps) 1 else 0
        if (ns != shift) { shift = ns; keyView.setShift(shift) }
    }

    // ---------- key callbacks ----------

    override fun onKey(key: Key, alt: Boolean) {
        val ic = currentInputConnection
        when (key.type) {
            KeyType.CHAR -> {
                val up = shift != 0 && mode == 0 && !numeric
                val t = if (alt) (key.alt ?: key.label) else if (up) key.label.uppercase() else key.label
                ic?.commitText(t, 1)
                if (shift == 1) { shift = 0; keyView.setShift(0) }
                updateAutoCaps()
            }
            KeyType.SPACE -> { ic?.commitText(" ", 1); updateAutoCaps() }
            KeyType.ENTER -> handleEnter()
            KeyType.SHIFT -> {
                val now = SystemClock.uptimeMillis()
                shift = when {
                    shift == 2 -> 0
                    shift == 1 && now - lastShiftTap < 350 -> 2
                    shift == 1 -> 0
                    else -> 1
                }
                lastShiftTap = now
                keyView.setShift(shift)
            }
            KeyType.SYMBOLS -> { mode = 1; refreshLayout() }
            KeyType.LETTERS -> { mode = 0; numeric = false; refreshLayout() }
            KeyType.MORE -> { mode = if (mode == 1) 2 else 1; refreshLayout() }
            else -> {}
        }
    }

    private fun handleEnter() {
        val info = currentInputEditorInfo
        val ic = currentInputConnection ?: return
        val action = (info?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        val noEnter = ((info?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noEnter && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
        updateAutoCaps()
    }

    override fun onBackspace() {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)
        if (!sel.isNullOrEmpty()) ic.commitText("", 1) else sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        updateAutoCaps()
    }

    override fun onCursor(dir: Int) {
        sendDownUpKeyEvents(if (dir < 0) KeyEvent.KEYCODE_DPAD_LEFT else KeyEvent.KEYCODE_DPAD_RIGHT)
    }

    override fun onSpaceLong() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
    }

    // ---------- toolbar / panels ----------

    private fun showKeys() {
        panel.visibility = View.GONE
        keyView.visibility = View.VISIBLE
    }

    private fun showPanel() {
        keyView.visibility = View.INVISIBLE   // keeps its height so the panel fills the same area
        panel.visibility = View.VISIBLE
    }

    private fun insertAndClose(text: String) {
        currentInputConnection?.commitText(text, 1)
        showKeys()
        updateAutoCaps()
    }

    private fun showClipboard() { panel.showClipboard(store) { insertAndClose(it) }; showPanel() }
    private fun showSnippets() { panel.showSnippets(store, { insertAndClose(it) }, { openSettings() }); showPanel() }
    private fun showEmoji() { panel.showEmoji { currentInputConnection?.commitText(it, 1) }; showPanel() }

    private fun cycleTheme() {
        val next = ThemeRegistry.next(settings.str(K.THEME, "neon"))
        settings.put(K.THEME, next.id)
        applyAll()
        Toast.makeText(this, next.name, Toast.LENGTH_SHORT).show()
    }

    private fun openSettings() {
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // ---------- clipboard capture ----------

    /** Best effort: Android only lets the focused keyboard read the clipboard, and may deny it. */
    private fun captureClipboard() {
        if (password || settings.bool(K.PAUSE, false)) return
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip ?: return
            if (clip.itemCount == 0) return
            if (clip.description?.extras?.getBoolean("android.content.extra.IS_SENSITIVE") == true) return
            val t = clip.getItemAt(0)?.coerceToText(this)?.toString()?.trim() ?: return
            if (t.isEmpty() || t.length > 5000) return
            store.addClip(t, settings.float(K.LIMIT, 50f).toInt())
        } catch (e: SecurityException) {
            // access denied by the system: ignore silently
        }
    }
}
